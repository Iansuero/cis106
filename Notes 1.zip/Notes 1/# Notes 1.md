# Notes 1

## What is Markdown?
Markdown is a simple syntax that formats text as headers, lists, boldface, and so on. This markup language is popular, and you definitely have apps that support it.

## What is Git?
Git is a tool used to keep track of changes to files, especially the code of the projects. It is termed a distributed version control system because of its behaviour to allow multiple people to work on the same project, even if they are not connected to a common server.

## What is GitHub?
GitHub is a for-profit company that offers a cloud-based Git repository hosting service. Essentially, it makes it a lot easier for individuals and teams to use Git for version control and collaboration.


## What is Slack?
Slack is a cloud-based messaging platform designed for teams and organizations of all sizes. It offers various features like direct messaging, group chat, video and audio calls, file sharing, and  app integrations that help teams communicate and work together efficiently
